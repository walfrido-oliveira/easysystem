<?php

namespace App\Budget;

use Illuminate\Database\Eloquent\Model;

class Area extends Model
{
    protected $fillable = [
        'name','active'
    ];
}
