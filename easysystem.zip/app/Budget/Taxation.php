<?php

namespace App\Budget;

use Illuminate\Database\Eloquent\Model;

class Taxation extends Model
{
    protected $fillable = [
        'name','active'
    ];
}
