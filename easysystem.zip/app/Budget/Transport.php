<?php

namespace App\Budget;

use Illuminate\Database\Eloquent\Model;

class Transport extends Model
{
    protected $fillable = [
        'name','active'
    ];
}
