<?php

namespace App\Http\Controllers;

use App\Uf;
use Illuminate\Http\Request;

class UfController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\UF  $uF
     * @return \Illuminate\Http\Response
     */
    public function show(Uf $uF)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\UF  $uF
     * @return \Illuminate\Http\Response
     */
    public function edit(Uf $uF)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\UF  $uF
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Uf $uF)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\UF  $uF
     * @return \Illuminate\Http\Response
     */
    public function destroy(Uf $uF)
    {
        //
    }
}
