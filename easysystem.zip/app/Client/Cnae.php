<?php

namespace App\Client;

use Illuminate\Database\Eloquent\Model;

class Cnae extends Model
{
    protected $fillable = [
        'cnae_id','desc'

    ];
}
