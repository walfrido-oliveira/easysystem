<?php

namespace App\Helpers;

use Response;

class AppHelper
{

    /**
     * Get a instance of class AppHelper
     *
     * @return AppHelper
     */
    public static function instance()
    {
        return new AppHelper();
    }
}
