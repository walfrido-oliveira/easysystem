<a href="{{ route('home') }}" class="link-light">Painel de Controle Administrativo</a> <i class="fa fa-chevron-right"></i>
<a href="{{ route('home.comercial') }}" class="link-light">Comercial</a> <i class="fa fa-chevron-right"></i>
<a href="{{ route('comercial.budget') }}" class="link-light">Orçamento</a> <i class="fa fa-chevron-right"></i>
<a href="{{ route('area.index') }}" class="link-light">Áreas</a>
