@extends('layouts.app')

@section('content')
    <div class="content">
        <div class="title m-b-md">
            {{ config('app.name', 'EasySystem') }}
        </div>
    </div>
@endsection
