<?php

return [
    'ok' => 'Verificar endereço de email'
];
